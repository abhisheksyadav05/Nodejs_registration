const express = require('express');
const { createUser } = require('./api/Users/user.controller');
const app = express();
const userRouter = require("./api/Users/user.router");
app.use(express.json());


// app.get("/api",(req,res)=>{
//     res.json({
//         sucess :1 ,
//         message : 'This is rest api working'
//     });
// });
app.use("/api/users", userRouter);
app.listen(3000, () =>{
    console.log("Server up and Connected");

})